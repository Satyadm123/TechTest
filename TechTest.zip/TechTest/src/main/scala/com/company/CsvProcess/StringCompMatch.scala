package com.company.CsvProcess
import scala.math.min
object StringCompMatch {

  def  stringComp(s1: String, s2: String): Int = {
    def minimum(i1: Int, i2: Int, i3: Int) = min(min(i1, i2), i3)

    val s3 = s1 match{
      case null => ""
      case _ =>s1
    }

    val s4 = s2 match{
      case null => ""
      case _ =>s2
    }
    var dist = ( new Array[Int](s3.length + 1),
      new Array[Int](s3.length + 1) )

    for (idx <- 0 to s3.length) dist._2(idx) = idx

    for (jdx <- 1 to s4.length) {
      val (newDist, oldDist) = dist
      newDist(0) = jdx
      for (idx <- 1 to s3.length) {
        newDist(idx) = minimum (
          oldDist(idx) + 1,
          newDist(idx-1) + 1,
          oldDist(idx-1) + (if (s3(idx-1) == s4(jdx-1)) 0 else 1)
        )
      }
      dist = dist.swap
    }

    dist._2(s3.length)
  }

  def getStringDistance = (names: String) => {

    val nameslist = names.split("\\|")
    val InData = nameslist(0)
    val matching = nameslist
      .slice(1, nameslist.length)
      .find(name => {
        1 to 2 contains stringComp(InData, name)
      })
    matching.getOrElse("NO_MATCH")


  }

}