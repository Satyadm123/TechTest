package com.company.CsvProcess

import org.apache.spark.sql._
import org.apache.spark.sql.functions.concat
import org.apache.spark.sql.functions.{col,lit}

object Transformations {

  /** Prepares  DataFrame for  operations by concatenating columns
    * The combined column will be used for string comparison for finding related record
    * Returns Dataframe
    * */
  def prepare(inputDf: DataFrame): DataFrame = {

    val transformedDf = inputDf.filter("surname is not null").withColumn("comp_col",concat(col("given_name"),
      col("surname"),col("date_of_birth"),col("sex"))).distinct()

    transformedDf

  }


  /** Compares two dataframes and creates resulting dataframe if the dataframes are related on comp_col column
    *
    *  Returns: DataFrame with 'matchingCol' column which contains similar/related/matching row of the second dataframe
    */

def compareDF2 (df1_1: DataFrame, df2_1: DataFrame): DataFrame = {
  val compCollist = df2_1
    .select("comp_col")
    .collect()
    .map(x => { x.getString(0) })
    .toList
    .mkString("|")

  val combined = df1_1.withColumn("comp_col_names", concat(col("comp_col"), lit("|"), lit(compCollist)))

  val stringDistanaceUdf = org.apache.spark.sql.functions.udf((stringA : String) => { StringCompMatch.getStringDistance(stringA); })
  val MatchedDf = combined.withColumn("matchingCol", stringDistanaceUdf(col("comp_col_names")))
  MatchedDf.drop("comp_col_names","comp_col").filter(" matchingCol != 'NO_MATCH' ")
}


}
