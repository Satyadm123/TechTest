package com.company.CsvProcess
import org.apache.spark.sql.SparkSession

object Main {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("CsvProcess Job")
      .master("local[*]")
      .getOrCreate()


    val ioHandler = new IOHandler(spark)
    val job = new MainJob(ioHandler)
    job.run()

    spark.stop()
  }


}
