package com.company.CsvProcess
import java.io.FileNotFoundException

import org.apache.spark.sql.{SparkSession, functions, _}

class IOHandler(spark: SparkSession) {

  def readCsv(filename: String, header: Boolean = true): Option[DataFrame] = {
    try {
      val df = spark.read.format("csv")
        .option("header", header)

        .option("inferSchema", "true")
        .load(filename)
      Some(df)
    }
    catch {
      case ex: FileNotFoundException => {
        println(s"File $filename not found")
        None
      }
      case unknown: Exception => {
        println(s"Unknown exception: $unknown")
        None
      }
    }
  }


  def outputdistinct(value:Long, value1:Long,value3:Long) ={
    println("Count of distinct records in the csv file is "+ value + " Count of  records in the csv file is "+ value1 + " Count of different  records in the csv file is "+ value3)}

  def writeCsv(df: DataFrame, filename: String, header: Boolean = true): Unit = {
    df.coalesce(1)
      .write
      .format("csv")
      .option("header", header)
      .save(filename)
  }


}