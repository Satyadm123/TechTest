package com.company.CsvProcess

import org.apache.spark.Logging


class MainJob (ioHandler: IOHandler) extends Logging {

  def run(): Unit = {

    // Load prepare and transform data

    ioHandler.readCsv("src/main/DataFile/input_file.csv") match{
      case Some(df) => {
        //prepare data
        val dataShedDf2_1 = Transformations.prepare(df).cache()
        //aggregations
        //get the related records from the csv in resultDF:Dataframe
        val resultDf = Transformations.compareDF2(dataShedDf2_1,dataShedDf2_1).cache()
        ioHandler.writeCsv(resultDf, "src/main/DataFile/Result/curated_related_data.csv")

      }
      case None => println("could not create dataframe")
    }



  }

}


