import org.scalatest._
import com.company.CsvProcess._

class DatasetSpec extends FunSpec with SparkSessionTest {

  import spark.implicits._



  describe("Comparing records for similarity within a dataframe when there is related records") {

    it("returns count of simiar/related records in a dataframe") {

      val inputDF = Seq(

        ("bilya","bhusan","1900-01-01","m"),
        ("billa","bhisan","1900-01-01","m"),
        ("Wilyam", "Premadasta","1950-01-01","f"),
        ("Wiliam", "Premadasa","1950-01-01","f"),
        ("Gedra", "Jobu","1960-01-01","f"),
          ("penram", "Jobu","1960-01-01","f")
      ).toDF("given_name","surname","date_of_birth","sex")

      val inputDF2=Transformations.prepare(inputDF)

      val resultDF= Transformations.compareDF2(inputDF2,inputDF2)
      assert(resultDF.count === 4)

    }




  }

  describe("Comparing records for similarity within a dataframe when there is no related records") {

    it("returns 0 as count of simiar/related records in a dataframe") {

      val inputDF = Seq(

        ("embarya","bhusan","1900-01-01","m"),
        ("billa","bhisan","1900-01-01","m"),
        ("zebran", "Premadasta","1950-01-01","f"),
        ("Wiliam", "Premadasa","1950-01-01","f"),
        ("Gedra", "Jobu","1960-01-01","f"),
        ("penram", "Jobu","1960-01-01","f")
      ).toDF("given_name","surname","date_of_birth","sex")

      val inputDF2=Transformations.prepare(inputDF)

      val resultDF= Transformations.compareDF2(inputDF2,inputDF2)
      assert(resultDF.count === 0)

    }




  }

}